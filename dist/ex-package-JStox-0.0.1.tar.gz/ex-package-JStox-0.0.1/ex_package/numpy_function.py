import numpy as np

def array_of_zeros(n):
    print(f'You requested an array of {n} zeros.')
    return np.zeros(n)